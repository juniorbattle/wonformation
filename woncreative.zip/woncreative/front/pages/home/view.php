<?php

$content->setEntityContent(
  $contentHTML
);
