<div class="content-signup col-md-4 col-md-offset-4">
  <h1>Sign up</h1>
  <div class="bar">&nbsp;</div>
  <p>Please give us your company name to access immediately at WonderCreative and begin your website creation</p>
  <div class="clearfix">&nbsp;</div>
  <form>
    <div class="row">
      <div class="contentGroup">
        <div class="formGroup">
          <i class="form-pin ti-user"></i>
          <input type="text" class="form-control" name="username" placeholder="Company name"/>
        </div>
      </div>
      <div class="clearfix">&nbsp;</div>
      <div class="contentGroup">
        <button class="btn btn-default btn-primary">Sign up</button>
      </div>
      <div class="clearfix">&nbsp;</div>
      <div class="col-md-12">Already have an account? <a href="<?php echo $config['url'] . 'login'; ?>">Log In</div>
      <div class="clearfix"></div>
    </div>
  </form>
</div>
