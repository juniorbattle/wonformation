<div class="content-resetpassword col-md-4 col-md-offset-4">
  <h1>Reset password</h1>
  <div class="bar">&nbsp;</div>
  <p>We'll send you an email with further instructions on how to reset your password.</p>
  <div class="clearfix">&nbsp;</div>
  <form>
    <div class="row">
      <div class="contentGroup">
        <div class="formGroup">
          <i class="form-pin ti-email"></i>
          <input type="text" class="form-control" name="email" placeholder="Email"/>
        </div>
      </div>
      <div class="clearfix">&nbsp;</div>
      <div class="contentGroup">
        <button class="btn btn-default btn-primary">Send email</button>
      </div>
      <div class="clearfix">&nbsp;</div>
    </div>
  </form>
</div>
